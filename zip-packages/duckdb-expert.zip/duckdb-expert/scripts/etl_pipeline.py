#!/usr/bin/env python3
"""
DuckDB ETL Pipeline

DuckDBを使用したETLパイプラインのテンプレートスクリプト。
データの抽出、変換、ロードを効率的に行います。

Usage:
    python etl_pipeline.py <config_file>
    python etl_pipeline.py --source data.csv --target output.parquet

Examples:
    python etl_pipeline.py config.yaml
    python etl_pipeline.py --source 'raw/*.csv' --target processed.parquet --transform "WHERE amount > 0"
"""

import argparse
import json
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

try:
    import duckdb
except ImportError:
    print("Error: duckdb is not installed. Run: pip install duckdb")
    sys.exit(1)


@dataclass
class ETLConfig:
    """ETLパイプラインの設定"""
    source_path: str
    target_path: str
    source_format: str = "auto"
    target_format: str = "parquet"
    transformations: List[str] = field(default_factory=list)
    select_columns: Optional[List[str]] = None
    where_clause: Optional[str] = None
    partition_by: Optional[List[str]] = None
    compression: str = "zstd"
    memory_limit: str = "4GB"
    threads: Optional[int] = None
    overwrite: bool = True
    validate: bool = True


class ETLPipeline:
    """DuckDBを使用したETLパイプライン"""

    def __init__(self, config: ETLConfig):
        """
        初期化

        Args:
            config: ETL設定
        """
        self.config = config
        self.con = duckdb.connect()
        self.con.execute(f"SET memory_limit = '{config.memory_limit}'")
        if config.threads:
            self.con.execute(f"SET threads = {config.threads}")

        self.metrics = {
            "start_time": None,
            "end_time": None,
            "source_rows": 0,
            "target_rows": 0,
            "transformations_applied": [],
            "errors": []
        }

    def run(self) -> Dict[str, Any]:
        """
        ETLパイプラインを実行

        Returns:
            実行結果のメトリクス
        """
        self.metrics["start_time"] = datetime.now().isoformat()

        try:
            # 1. Extract
            print(f"[Extract] Reading from: {self.config.source_path}")
            source_data = self._extract()

            # 2. Transform
            print("[Transform] Applying transformations...")
            transformed_data = self._transform(source_data)

            # 3. Validate (optional)
            if self.config.validate:
                print("[Validate] Running data quality checks...")
                self._validate(transformed_data)

            # 4. Load
            print(f"[Load] Writing to: {self.config.target_path}")
            self._load(transformed_data)

            self.metrics["end_time"] = datetime.now().isoformat()
            print("[Complete] ETL pipeline finished successfully")

        except Exception as e:
            self.metrics["errors"].append(str(e))
            self.metrics["end_time"] = datetime.now().isoformat()
            raise

        return self.metrics

    def _extract(self) -> str:
        """
        データの抽出

        Returns:
            一時ビュー名
        """
        source_path = self.config.source_path

        # ソース行数をカウント
        try:
            count_result = self.con.execute(f"""
                SELECT COUNT(*) FROM '{source_path}'
            """).fetchone()
            self.metrics["source_rows"] = count_result[0]
            print(f"  Source rows: {self.metrics['source_rows']:,}")
        except Exception as e:
            print(f"  Warning: Could not count source rows: {e}")

        # 一時ビューとして登録
        self.con.execute(f"""
            CREATE OR REPLACE VIEW _source_data AS
            SELECT * FROM '{source_path}'
        """)

        return "_source_data"

    def _transform(self, source_view: str) -> str:
        """
        データの変換

        Args:
            source_view: ソースビュー名

        Returns:
            変換後のビュー名
        """
        current_view = source_view

        # カラム選択
        if self.config.select_columns:
            columns = ", ".join([f'"{c}"' for c in self.config.select_columns])
            self.con.execute(f"""
                CREATE OR REPLACE VIEW _selected AS
                SELECT {columns} FROM {current_view}
            """)
            current_view = "_selected"
            self.metrics["transformations_applied"].append(
                f"Column selection: {len(self.config.select_columns)} columns"
            )
            print(f"  Applied column selection: {len(self.config.select_columns)} columns")

        # WHERE句
        if self.config.where_clause:
            self.con.execute(f"""
                CREATE OR REPLACE VIEW _filtered AS
                SELECT * FROM {current_view}
                WHERE {self.config.where_clause}
            """)
            current_view = "_filtered"
            self.metrics["transformations_applied"].append(
                f"Filter: {self.config.where_clause}"
            )
            print(f"  Applied filter: {self.config.where_clause}")

        # カスタム変換
        for i, transformation in enumerate(self.config.transformations):
            view_name = f"_transform_{i}"
            # 変換がSELECT文の場合
            if transformation.strip().upper().startswith("SELECT"):
                sql = transformation.replace("FROM _input", f"FROM {current_view}")
            else:
                # 変換が関数やカラム変換の場合
                sql = f"""
                    SELECT *, {transformation}
                    FROM {current_view}
                """

            try:
                self.con.execute(f"""
                    CREATE OR REPLACE VIEW {view_name} AS
                    {sql}
                """)
                current_view = view_name
                self.metrics["transformations_applied"].append(f"Custom: {transformation[:50]}...")
                print(f"  Applied transformation {i+1}: {transformation[:50]}...")
            except Exception as e:
                print(f"  Warning: Transformation {i+1} failed: {e}")
                self.metrics["errors"].append(f"Transform {i+1}: {str(e)}")

        # 最終ビューを作成
        self.con.execute(f"""
            CREATE OR REPLACE VIEW _transformed AS
            SELECT * FROM {current_view}
        """)

        return "_transformed"

    def _validate(self, transformed_view: str) -> bool:
        """
        データ品質の検証

        Args:
            transformed_view: 検証対象のビュー名

        Returns:
            検証結果（True: 成功, False: 警告あり）
        """
        warnings = []

        # 行数チェック
        result = self.con.execute(f"""
            SELECT COUNT(*) FROM {transformed_view}
        """).fetchone()
        row_count = result[0]

        if row_count == 0:
            warnings.append("Warning: Transformed data has 0 rows")

        # NULL値チェック
        schema = self.con.execute(f"""
            DESCRIBE SELECT * FROM {transformed_view}
        """).fetchall()

        for col in schema:
            col_name = col[0]
            null_count = self.con.execute(f"""
                SELECT COUNT(*) FILTER (WHERE "{col_name}" IS NULL)
                FROM {transformed_view}
            """).fetchone()[0]

            if null_count > 0:
                null_pct = 100.0 * null_count / row_count if row_count > 0 else 0
                if null_pct > 50:
                    warnings.append(f"Warning: Column '{col_name}' has {null_pct:.1f}% NULL values")

        if warnings:
            for w in warnings:
                print(f"  {w}")
                self.metrics["errors"].append(w)
            return False

        print("  Validation passed")
        return True

    def _load(self, transformed_view: str):
        """
        データのロード（書き出し）

        Args:
            transformed_view: 書き出し対象のビュー名
        """
        target_format = self.config.target_format.lower()
        target_path = self.config.target_path

        # パーティション設定
        partition_clause = ""
        if self.config.partition_by:
            partition_columns = ", ".join(self.config.partition_by)
            partition_clause = f", PARTITION_BY ({partition_columns})"

        # 書き出し実行
        if target_format == "parquet":
            self.con.execute(f"""
                COPY (SELECT * FROM {transformed_view})
                TO '{target_path}'
                (FORMAT PARQUET, COMPRESSION '{self.config.compression}'{partition_clause})
            """)
        elif target_format == "csv":
            self.con.execute(f"""
                COPY (SELECT * FROM {transformed_view})
                TO '{target_path}'
                (FORMAT CSV, HEADER true{partition_clause})
            """)
        elif target_format == "json":
            self.con.execute(f"""
                COPY (SELECT * FROM {transformed_view})
                TO '{target_path}'
                (FORMAT JSON)
            """)
        else:
            raise ValueError(f"Unsupported target format: {target_format}")

        # 出力行数
        self.metrics["target_rows"] = self.con.execute(f"""
            SELECT COUNT(*) FROM {transformed_view}
        """).fetchone()[0]

        print(f"  Target rows: {self.metrics['target_rows']:,}")

    def close(self):
        """接続のクローズ"""
        self.con.close()


class ETLBuilder:
    """ETLパイプラインのビルダー"""

    def __init__(self, source_path: str):
        """
        ビルダーの初期化

        Args:
            source_path: ソースファイルパス
        """
        self._config = {
            "source_path": source_path,
            "target_path": None,
            "transformations": [],
        }

    def to(self, target_path: str, format: str = "parquet") -> "ETLBuilder":
        """出力先の設定"""
        self._config["target_path"] = target_path
        self._config["target_format"] = format
        return self

    def select(self, *columns: str) -> "ETLBuilder":
        """カラム選択"""
        self._config["select_columns"] = list(columns)
        return self

    def where(self, condition: str) -> "ETLBuilder":
        """フィルタ条件"""
        self._config["where_clause"] = condition
        return self

    def transform(self, sql: str) -> "ETLBuilder":
        """カスタム変換を追加"""
        self._config["transformations"].append(sql)
        return self

    def partition_by(self, *columns: str) -> "ETLBuilder":
        """パーティション設定"""
        self._config["partition_by"] = list(columns)
        return self

    def compress(self, compression: str) -> "ETLBuilder":
        """圧縮設定"""
        self._config["compression"] = compression
        return self

    def memory(self, limit: str) -> "ETLBuilder":
        """メモリ制限"""
        self._config["memory_limit"] = limit
        return self

    def build(self) -> ETLConfig:
        """設定オブジェクトを構築"""
        if not self._config.get("target_path"):
            raise ValueError("Target path is required. Call .to() first.")
        return ETLConfig(**self._config)

    def run(self) -> Dict[str, Any]:
        """パイプラインを構築して実行"""
        config = self.build()
        pipeline = ETLPipeline(config)
        try:
            return pipeline.run()
        finally:
            pipeline.close()


def from_source(source_path: str) -> ETLBuilder:
    """
    ETLパイプラインを開始

    Args:
        source_path: ソースファイルパス

    Returns:
        ETLBuilder

    Example:
        >>> result = (
        ...     from_source('data/*.csv')
        ...     .select('id', 'name', 'amount')
        ...     .where('amount > 0')
        ...     .transform("CAST(amount AS DOUBLE) as amount_normalized")
        ...     .to('output.parquet')
        ...     .partition_by('year', 'month')
        ...     .run()
        ... )
    """
    return ETLBuilder(source_path)


def load_config_from_yaml(config_path: str) -> ETLConfig:
    """YAMLファイルから設定を読み込み"""
    try:
        import yaml
    except ImportError:
        raise ImportError("PyYAML is required for YAML config. Run: pip install pyyaml")

    with open(config_path, "r") as f:
        config_dict = yaml.safe_load(f)

    return ETLConfig(**config_dict)


def load_config_from_json(config_path: str) -> ETLConfig:
    """JSONファイルから設定を読み込み"""
    with open(config_path, "r") as f:
        config_dict = json.load(f)

    return ETLConfig(**config_dict)


def main():
    parser = argparse.ArgumentParser(
        description="DuckDB ETL Pipeline - Extract, Transform, Load data efficiently",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Using config file
    python etl_pipeline.py config.yaml

    # Direct command line
    python etl_pipeline.py --source 'raw/*.csv' --target processed.parquet
    python etl_pipeline.py --source data.csv --target output.parquet --where "amount > 0"
    python etl_pipeline.py --source data.csv --target output/ --partition year month
        """
    )

    parser.add_argument(
        "config_file",
        nargs="?",
        help="Configuration file (YAML or JSON)"
    )
    parser.add_argument(
        "--source", "-s",
        help="Source file path"
    )
    parser.add_argument(
        "--target", "-t",
        help="Target file path"
    )
    parser.add_argument(
        "--format", "-f",
        choices=["parquet", "csv", "json"],
        default="parquet",
        help="Target format (default: parquet)"
    )
    parser.add_argument(
        "--select",
        nargs="+",
        help="Columns to select"
    )
    parser.add_argument(
        "--where", "-w",
        help="WHERE clause for filtering"
    )
    parser.add_argument(
        "--partition",
        nargs="+",
        help="Partition by columns"
    )
    parser.add_argument(
        "--compression",
        default="zstd",
        help="Compression (default: zstd)"
    )
    parser.add_argument(
        "--memory",
        default="4GB",
        help="Memory limit (default: 4GB)"
    )
    parser.add_argument(
        "--no-validate",
        action="store_true",
        help="Skip validation"
    )

    args = parser.parse_args()

    # 設定の読み込み
    if args.config_file:
        config_path = Path(args.config_file)
        if config_path.suffix in [".yaml", ".yml"]:
            config = load_config_from_yaml(args.config_file)
        elif config_path.suffix == ".json":
            config = load_config_from_json(args.config_file)
        else:
            print(f"Error: Unsupported config format: {config_path.suffix}")
            sys.exit(1)
    elif args.source and args.target:
        config = ETLConfig(
            source_path=args.source,
            target_path=args.target,
            target_format=args.format,
            select_columns=args.select,
            where_clause=args.where,
            partition_by=args.partition,
            compression=args.compression,
            memory_limit=args.memory,
            validate=not args.no_validate
        )
    else:
        parser.print_help()
        print("\nError: Either config file or --source and --target are required")
        sys.exit(1)

    # パイプラインの実行
    pipeline = ETLPipeline(config)
    try:
        start_time = time.time()
        metrics = pipeline.run()
        elapsed = time.time() - start_time

        print("\n" + "=" * 50)
        print("ETL Pipeline Summary")
        print("=" * 50)
        print(f"Source: {config.source_path}")
        print(f"Target: {config.target_path}")
        print(f"Source Rows: {metrics['source_rows']:,}")
        print(f"Target Rows: {metrics['target_rows']:,}")
        print(f"Transformations: {len(metrics['transformations_applied'])}")
        print(f"Elapsed Time: {elapsed:.2f} seconds")

        if metrics['errors']:
            print(f"\nWarnings/Errors: {len(metrics['errors'])}")
            for error in metrics['errors']:
                print(f"  - {error}")

    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        pipeline.close()


if __name__ == "__main__":
    main()
