# DuckDB Performance Tuning Guide

DuckDBで大規模データを効率的に処理するためのパフォーマンスチューニングガイド。

## 1. メモリ管理

### メモリ制限の設定

```python
import duckdb

con = duckdb.connect()

# メモリ制限の設定（デフォルト: システムメモリの80%）
con.execute("SET memory_limit = '8GB'")

# 現在の設定確認
con.execute("SELECT current_setting('memory_limit')").fetchone()
```

### 一時ファイル（スピルトゥディスク）

メモリ制限を超えた場合、DuckDBは自動的にディスクにスピルします。

```python
# スピル先ディレクトリの設定
con.execute("SET temp_directory = '/path/to/fast/ssd'")

# 現在の設定確認
con.execute("SELECT current_setting('temp_directory')").fetchone()
```

**ベストプラクティス:**
- SSDをスピル先に指定する
- 十分なディスク容量を確保（処理データの2-3倍）
- 共有ストレージは避ける

### メモリプレッシャー時の挙動

```python
# 外部ソート・集計の有効化（メモリ不足時にディスク使用）
con.execute("SET enable_external_access = true")

# プログレス表示（長時間クエリの監視）
con.execute("SET enable_progress_bar = true")
```

## 2. 並列処理の最適化

### スレッド数の調整

```python
# スレッド数の設定（デフォルト: CPUコア数）
con.execute("SET threads = 8")

# 現在の設定確認
con.execute("SELECT current_setting('threads')").fetchone()
```

**ガイドライン:**
- I/Oバウンド処理: コア数の1-2倍
- CPUバウンド処理: 物理コア数
- 他のプロセスと共存: コア数の50-75%

### パイプライン並列化

DuckDBは自動的にパイプライン並列化を行いますが、クエリ構造が影響します。

```sql
-- 並列化しやすいパターン
SELECT category, SUM(amount) FROM sales GROUP BY category;

-- 並列化が制限されるパターン（ORDER BY付きウィンドウ関数）
SELECT *, ROW_NUMBER() OVER (ORDER BY date) FROM sales;
```

## 3. ファイル形式の最適化

### Parquet vs CSV

| 項目 | Parquet | CSV |
|------|---------|-----|
| 読み込み速度 | 非常に高速 | 遅い |
| 列選択 | 必要な列のみ読む | 全列スキャン |
| 圧縮 | 内蔵（zstd, snappy等） | なし |
| 型情報 | 保持 | 推論が必要 |
| ファイルサイズ | 小さい（1/5〜1/10） | 大きい |

**推奨: 分析用途では常にParquet形式を使用**

### Parquet書き出しの最適化

```python
# 最適な圧縮設定
con.execute("""
    COPY (SELECT * FROM data)
    TO 'output.parquet'
    (FORMAT PARQUET, COMPRESSION 'zstd', COMPRESSION_LEVEL 3)
""")

# 行グループサイズの調整（デフォルト: 122,880行）
con.execute("""
    COPY (SELECT * FROM data)
    TO 'output.parquet'
    (FORMAT PARQUET, ROW_GROUP_SIZE 100000)
""")
```

### パーティショニング

大規模データセットでは、パーティショニングがクエリ性能を大幅に向上させます。

```python
# Hiveスタイルパーティション出力
con.execute("""
    COPY (SELECT * FROM sales)
    TO 'sales_partitioned'
    (FORMAT PARQUET, PARTITION_BY (year, month))
""")

# 結果: sales_partitioned/year=2024/month=01/data.parquet

# パーティションプルーニングを活用したクエリ
con.execute("""
    SELECT * FROM 'sales_partitioned/**/*.parquet'
    WHERE year = 2024 AND month = 1
""")  # 関連パーティションのみスキャン
```

## 4. クエリ最適化

### 列の選択

```python
# Bad: 全列選択
con.execute("SELECT * FROM large_table")

# Good: 必要な列のみ
con.execute("SELECT id, name, amount FROM large_table")

# Parquetの場合、列プルーニングが自動適用
```

### 早期フィルタリング

```python
# Good: WHERE句でフィルタ（Predicate Pushdown）
con.execute("""
    SELECT * FROM 'data.parquet'
    WHERE date >= '2024-01-01' AND category = 'A'
""")

# Bad: サブクエリ後のフィルタ
con.execute("""
    SELECT * FROM (
        SELECT * FROM 'data.parquet'
    ) sub
    WHERE date >= '2024-01-01'
""")
```

### JOINの最適化

```python
# 小さいテーブルを右側に（ハッシュジョインの効率化）
con.execute("""
    SELECT *
    FROM large_fact_table f
    JOIN small_dim_table d ON f.key = d.key
""")

# INの代わりにSEMI JOINを使用（大量の値がある場合）
con.execute("""
    SELECT * FROM orders
    WHERE customer_id IN (SELECT id FROM vip_customers)
""")
# DuckDBは自動的にSEMI JOINに変換
```

### サブクエリのマテリアライズ

```python
# 複数回参照されるサブクエリはCTEでマテリアライズ
con.execute("""
    WITH expensive_calc AS MATERIALIZED (
        SELECT category, SUM(amount) as total
        FROM sales
        GROUP BY category
    )
    SELECT a.*, b.*
    FROM expensive_calc a
    JOIN expensive_calc b ON a.category != b.category
""")
```

## 5. EXPLAIN ANALYZEの活用

### クエリプランの確認

```python
# 実行プランの表示
plan = con.execute("""
    EXPLAIN ANALYZE
    SELECT category, SUM(amount)
    FROM 'sales.parquet'
    WHERE year = 2024
    GROUP BY category
""").fetchdf()
print(plan)
```

### 確認すべきポイント

1. **Filter Pushdown**: フィルタがスキャン時に適用されているか
2. **Column Pruning**: 必要な列のみ読み込んでいるか
3. **Hash Join vs Nested Loop**: 適切なJOINアルゴリズムか
4. **Parallelism**: 並列実行されているか

### プロファイリング

```python
# 詳細なプロファイリング
con.execute("PRAGMA enable_profiling = 'query_tree'")
con.execute("PRAGMA profiling_output = '/tmp/profile.json'")

# クエリ実行
con.execute("SELECT ...")

# プロファイル結果の確認
con.execute("PRAGMA disable_profiling")
```

## 6. データ読み込みの最適化

### 並列読み込み

```python
# 複数ファイルの並列読み込み
con.execute("SELECT * FROM 'data/*.parquet'")

# ファイル数が多い場合のパフォーマンス向上
con.execute("""
    SELECT * FROM read_parquet(
        'data/*.parquet',
        parallel = true
    )
""")
```

### サンプリングによる高速探索

```python
# パーセントサンプル
con.execute("""
    SELECT * FROM 'large_data.parquet'
    USING SAMPLE 1%
""")

# 固定行数サンプル（Reservoir Sampling）
con.execute("""
    SELECT * FROM 'large_data.parquet'
    USING SAMPLE reservoir(10000 ROWS)
""")

# 再現可能なサンプル（シード指定）
con.execute("""
    SELECT * FROM 'large_data.parquet'
    USING SAMPLE 1% (bernoulli, 42)
""")
```

### ストリーミング処理

```python
# 大規模データのチャンク処理
result = con.execute("SELECT * FROM 'huge.parquet'")

# Arrow RecordBatchで効率的に取得
for batch in result.fetch_record_batch(100000):
    df = batch.to_pandas()
    process(df)
```

## 7. 永続化データベースの最適化

### インデックスとART

DuckDBは自動的にAdaptive Radix Tree (ART)インデックスを使用します。

```python
# プライマリキー制約（ARTインデックスが自動作成）
con.execute("""
    CREATE TABLE users (
        id INTEGER PRIMARY KEY,
        name VARCHAR
    )
""")

# 明示的なインデックス作成（通常は不要）
con.execute("CREATE INDEX idx_name ON users(name)")
```

### テーブル統計の更新

```python
# 統計情報の収集（クエリオプティマイザ用）
con.execute("ANALYZE users")

# 全テーブルの統計更新
con.execute("ANALYZE")
```

### VACUUM

```python
# 不要なデータの削除・圧縮
con.execute("VACUUM")

# 特定テーブル
con.execute("VACUUM users")
```

## 8. 一般的なパフォーマンス問題と解決策

### 問題1: メモリ不足エラー

```
OutOfMemoryException: could not allocate block of X bytes
```

**解決策:**
```python
# メモリ制限を上げる
con.execute("SET memory_limit = '16GB'")

# スピルを有効化
con.execute("SET temp_directory = '/tmp/duckdb'")

# クエリを分割（LIMIT, OFFSET）
con.execute("SELECT * FROM large_table LIMIT 1000000 OFFSET 0")
```

### 問題2: 遅いCSV読み込み

**解決策:**
```python
# Parquetに変換
con.execute("""
    COPY (SELECT * FROM 'slow.csv')
    TO 'fast.parquet' (FORMAT PARQUET)
""")

# または、スキーマを明示（型推論をスキップ）
con.execute("""
    SELECT * FROM read_csv('data.csv',
        columns = {'id': 'INTEGER', 'name': 'VARCHAR', 'value': 'DOUBLE'},
        auto_detect = false
    )
""")
```

### 問題3: JOINが遅い

**解決策:**
```python
# 小さいテーブルを先にフィルタ
con.execute("""
    WITH filtered_dim AS (
        SELECT * FROM dim_table WHERE active = true
    )
    SELECT * FROM fact_table f
    JOIN filtered_dim d ON f.key = d.key
""")

# カーディナリティが低い列でJOIN
```

### 問題4: GROUP BYが遅い

**解決策:**
```python
# カーディナリティの高いキーを減らす
# 必要な集計のみ行う
con.execute("""
    SELECT
        DATE_TRUNC('day', timestamp) as day,  -- 秒単位ではなく日単位
        category,
        SUM(amount)
    FROM sales
    GROUP BY 1, 2
""")
```

## 9. ベンチマーク・監視

### クエリ実行時間の測定

```python
import time

start = time.time()
result = con.execute("SELECT ...").fetchdf()
elapsed = time.time() - start
print(f"Execution time: {elapsed:.2f} seconds")
```

### プログレスバー

```python
# 長時間クエリのプログレス表示
con.execute("SET enable_progress_bar = true")
con.execute("SET enable_progress_bar_print = true")

# 実行
con.execute("SELECT * FROM huge_table")  # プログレスが表示される
```

### システムリソースの監視

```python
# 現在のメモリ使用量
con.execute("SELECT * FROM duckdb_memory()").fetchdf()

# 実行中のクエリ
con.execute("SELECT * FROM duckdb_queries()").fetchdf()
```
